package DataModels;

public record Product(String id, String name, double price){
}